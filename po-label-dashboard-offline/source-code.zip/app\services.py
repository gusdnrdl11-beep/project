from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone

from app.domain import ProductionOrder
from app.providers.base import ProductionDataProvider
from app.repository import LabelEventRepository


class DashboardService:
    def __init__(
        self,
        provider: ProductionDataProvider,
        repository: LabelEventRepository,
        refresh_interval_seconds: float,
    ) -> None:
        self.provider = provider
        self.repository = repository
        self.refresh_interval_seconds = refresh_interval_seconds
        self._orders: dict[str, ProductionOrder] = {}
        self._snapshot: list[dict] = []
        self._refreshed_at: datetime | None = None
        self._lock = asyncio.Lock()

    async def refresh(self) -> dict:
        async with self._lock:
            orders = await self.provider.list_orders()
            totals = self.repository.totals_by_po()
            snapshot: list[dict] = []
            for order in orders:
                printed_qty = order.base_printed_qty + totals.get(order.po, 0)
                rate = round((printed_qty / order.plan_qty * 100) if order.plan_qty else 0, 1)
                snapshot.append(
                    {
                        **order.as_dict(),
                        "printed_qty": printed_qty,
                        "progress_rate": rate,
                    }
                )
            self._orders = {order.po: order for order in orders}
            self._snapshot = snapshot
            self._refreshed_at = datetime.now(timezone.utc)
            return self.get_dashboard()

    def get_dashboard(self) -> dict:
        if self._refreshed_at is None:
            raise RuntimeError("대시보드가 아직 초기화되지 않았습니다.")
        next_refresh = self._refreshed_at + timedelta(seconds=self.refresh_interval_seconds)
        return {
            "items": self._snapshot,
            "count": len(self._snapshot),
            "refreshed_at": self._refreshed_at.isoformat(),
            "next_refresh_at": next_refresh.isoformat(),
            "refresh_interval_seconds": self.refresh_interval_seconds,
        }

    def print_label(self, po: str, quantity: int) -> dict:
        order = self._orders.get(po)
        if order is None:
            raise KeyError(po)
        barcode = f"PO{po}-{int(datetime.now(timezone.utc).timestamp() * 1000)}"
        event = self.repository.create_event(po=po, barcode=barcode, quantity=quantity)
        return {**event, "machine": order.machine, "item": order.item}

    async def run_scheduler(self, stop_event: asyncio.Event) -> None:
        while not stop_event.is_set():
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=self.refresh_interval_seconds)
            except TimeoutError:
                await self.refresh()

