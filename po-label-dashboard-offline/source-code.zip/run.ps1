$ErrorActionPreference = 'Stop'
$projectPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $projectPath

if (-not (Test-Path -LiteralPath '.venv')) {
    python -m venv .venv
}

& .\.venv\Scripts\python.exe -m pip install -r requirements.txt

if ($env:DASHBOARD_PORT) {
    $dashboardPort = [int]$env:DASHBOARD_PORT
} else {
    $busyPorts = [System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners().Port
    $dashboardPort = 8010..8020 | Where-Object { $_ -notin $busyPorts } | Select-Object -First 1
}

if (-not $dashboardPort) {
    throw '사용 가능한 대시보드 포트를 찾지 못했습니다.'
}

$dashboardUrl = "http://127.0.0.1:$dashboardPort/"
Write-Host "`n웹 대시보드를 엽니다: $dashboardUrl" -ForegroundColor Cyan
$browserJob = Start-Job -ScriptBlock {
    param($url)
    Start-Sleep -Seconds 2
    Start-Process $url
} -ArgumentList $dashboardUrl

try {
    & .\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port $dashboardPort
} finally {
    Remove-Job -Job $browserJob -Force -ErrorAction SilentlyContinue
}
