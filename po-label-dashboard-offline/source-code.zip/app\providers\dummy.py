from __future__ import annotations

from app.domain import ProductionOrder


class DummyProductionDataProvider:
    async def list_orders(self) -> list[ProductionOrder]:
        return [
            ProductionOrder("12345678", "27호기", "53398-0300", 100_000, 76_800),
            ProductionOrder("12345679", "64호기", "501330-0400", 80_000, 61_120),
            ProductionOrder("12345680", "118호기", "53261-0571", 120_000, 91_200),
            ProductionOrder("12345681", "175호기", "502352-0600", 90_000, 67_680),
        ]

