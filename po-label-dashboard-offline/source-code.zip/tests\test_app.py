from __future__ import annotations

import time
from pathlib import Path

from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app


def make_client(tmp_path: Path, interval: float = 10_800) -> TestClient:
    settings = Settings(database_path=tmp_path / "test.db", refresh_interval_seconds=interval)
    return TestClient(create_app(settings))


def test_label_is_staged_until_manual_refresh(tmp_path: Path) -> None:
    with make_client(tmp_path) as client:
        before = client.get("/api/dashboard").json()
        assert before["items"][0]["printed_qty"] == 76_800

        created = client.post("/api/labels", json={"po": "12345678", "quantity": 25})
        assert created.status_code == 201
        assert client.get("/api/dashboard").json()["items"][0]["printed_qty"] == 76_800

        refreshed = client.post("/api/dashboard/refresh").json()
        assert refreshed["items"][0]["printed_qty"] == 76_825
        label = client.get(created.json()["print_url"])
        assert label.status_code == 200
        assert "<svg" in label.text
        assert "25 EA" in label.text


def test_scheduler_refreshes_automatically(tmp_path: Path) -> None:
    with make_client(tmp_path, interval=0.1) as client:
        client.post("/api/labels", json={"po": "12345679", "quantity": 40})
        deadline = time.monotonic() + 1.5
        printed = 0
        while time.monotonic() < deadline:
            items = client.get("/api/dashboard").json()["items"]
            printed = next(item["printed_qty"] for item in items if item["po"] == "12345679")
            if printed == 61_160:
                break
            time.sleep(0.03)
        assert printed == 61_160


def test_rejects_unknown_po_and_bad_quantity(tmp_path: Path) -> None:
    with make_client(tmp_path) as client:
        assert client.post("/api/labels", json={"po": "NOPE", "quantity": 1}).status_code == 404
        assert client.post("/api/labels", json={"po": "12345678", "quantity": 0}).status_code == 422


def test_dashboard_and_csv_are_served(tmp_path: Path) -> None:
    with make_client(tmp_path) as client:
        assert "사출생산 대시보드" in client.get("/").text
        csv_response = client.get("/api/dashboard.csv")
        assert csv_response.status_code == 200
        assert "12345678" in csv_response.text


def test_po_sheets_have_one_scannable_order_per_machine(tmp_path: Path) -> None:
    with make_client(tmp_path) as client:
        response = client.get("/po-sheets")
        assert response.status_code == 200
        assert response.text.count('class="sheet"') == 4
        assert response.text.count("<svg") == 4
        for machine, po in [
            ("27호기", "12345678"),
            ("64호기", "12345679"),
            ("118호기", "12345680"),
            ("175호기", "12345681"),
        ]:
            assert machine in response.text
            assert po in response.text


def test_po_sheet_barcode_value_drives_label_count(tmp_path: Path) -> None:
    with make_client(tmp_path) as client:
        sheet = client.get("/po-sheets")
        assert ">12345680<" in sheet.text
        created = client.post("/api/labels", json={"po": "12345680", "quantity": 55})
        assert created.status_code == 201
        refreshed = client.post("/api/dashboard/refresh").json()
        order = next(item for item in refreshed["items"] if item["po"] == "12345680")
        assert order["printed_qty"] == 91_255
