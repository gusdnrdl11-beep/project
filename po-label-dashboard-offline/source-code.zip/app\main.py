from __future__ import annotations

import asyncio
import csv
import html
import io
from contextlib import asynccontextmanager, suppress
from pathlib import Path

import barcode
from barcode.writer import SVGWriter
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from app.config import PROJECT_ROOT, Settings
from app.providers import CompanyApiProvider, DummyProductionDataProvider
from app.repository import LabelEventRepository
from app.services import DashboardService


class PrintLabelRequest(BaseModel):
    po: str = Field(min_length=1, max_length=64)
    quantity: int = Field(gt=0, le=1_000_000)


def _make_provider(settings: Settings):
    if settings.data_provider == "dummy":
        return DummyProductionDataProvider()
    if settings.data_provider == "company_api":
        return CompanyApiProvider(
            settings.company_api_base_url,
            settings.company_api_token,
            settings.company_api_timeout_seconds,
        )
    raise ValueError(f"지원하지 않는 DATA_PROVIDER: {settings.data_provider}")


def create_app(settings: Settings | None = None) -> FastAPI:
    app_settings = settings or Settings.from_env()
    repository = LabelEventRepository(app_settings.database_path)
    service = DashboardService(
        provider=_make_provider(app_settings),
        repository=repository,
        refresh_interval_seconds=app_settings.refresh_interval_seconds,
    )

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        await service.refresh()
        stop_event = asyncio.Event()
        scheduler_task = asyncio.create_task(service.run_scheduler(stop_event))
        try:
            yield
        finally:
            stop_event.set()
            scheduler_task.cancel()
            with suppress(asyncio.CancelledError):
                await scheduler_task

    app = FastAPI(title="PO Label Dashboard API", version="1.0.0", lifespan=lifespan)
    app.state.service = service
    app.state.repository = repository
    app.mount("/static", StaticFiles(directory=PROJECT_ROOT / "static"), name="static")

    @app.get("/", response_class=HTMLResponse)
    async def dashboard() -> HTMLResponse:
        source = (PROJECT_ROOT / "static" / "dashboard.html").read_text(encoding="utf-8")
        enhanced = source.replace("</body>", '<script src="/static/dashboard.js"></script></body>')
        return HTMLResponse(enhanced)

    @app.get("/scanner", response_class=HTMLResponse)
    async def scanner() -> HTMLResponse:
        return HTMLResponse((PROJECT_ROOT / "static" / "scanner.html").read_text(encoding="utf-8"))

    @app.get("/api/dashboard")
    async def dashboard_data() -> dict:
        return service.get_dashboard()

    @app.get("/po-sheets", response_class=HTMLResponse)
    async def po_sheets() -> HTMLResponse:
        """현재 생산 대상 전체를 설비별 A4 PO 작업지로 만든다."""
        sheets: list[str] = []
        for order in service.get_dashboard()["items"]:
            po = html.escape(str(order["po"]))
            machine = html.escape(str(order["machine"]))
            item = html.escape(str(order["item"]))
            barcode_svg = barcode.get("code128", str(order["po"]), writer=SVGWriter()).render(
                writer_options={"write_text": True, "module_height": 18.0, "font_size": 11}
            ).decode("utf-8")
            sheets.append(
                f"""<article class=\"sheet\">
                <header><div><div class=\"eyebrow\">PRODUCTION ORDER</div><h1>{machine} 생산 작업지</h1></div><div class=\"status\">더미 테스트용</div></header>
                <section class=\"order-grid\">
                  <div><span>PO 번호</span><strong>{po}</strong></div>
                  <div><span>설비명</span><strong>{machine}</strong></div>
                  <div><span>아이템명</span><strong>{item}</strong></div>
                  <div><span>계획수량</span><strong>{order['plan_qty']:,} EA</strong></div>
                  <div><span>현재 라벨 출력수량</span><strong>{order['printed_qty']:,} EA</strong></div>
                  <div><span>현재 진행률</span><strong>{order['progress_rate']:.1f}%</strong></div>
                </section>
                <section class=\"barcode\"><div>스캐너 입력용 PO 바코드</div>{barcode_svg}</section>
                <footer><span>① PO 바코드 스캔</span><span>② 라벨 수량 입력 및 출력</span><span>③ 대시보드 수동 업데이트</span></footer>
                </article>"""
            )
        return HTMLResponse((
            """<!doctype html><html lang=\"ko\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
            <title>설비별 가상 PO 작업지</title><style>
            *{box-sizing:border-box}body{margin:0;background:#e2e8f0;color:#0f172a;font-family:Arial,sans-serif}.toolbar{position:sticky;top:0;z-index:2;display:flex;align-items:center;justify-content:space-between;padding:12px 20px;background:#fff;border-bottom:1px solid #cbd5e1}.toolbar strong{font-size:17px}.toolbar div{display:flex;gap:8px}.toolbar button,.toolbar a{height:38px;padding:0 14px;border-radius:4px;display:inline-flex;align-items:center;border:1px solid #cbd5e1;background:#fff;color:#0f172a;font-weight:700;text-decoration:none;cursor:pointer}.toolbar button{background:#0077c8;color:#fff;border-color:#0066aa}.sheet{width:210mm;min-height:297mm;margin:16px auto;padding:18mm;background:#fff;box-shadow:0 2px 12px rgba(15,23,42,.12);page-break-after:always}.sheet header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #0077c8;padding-bottom:10mm}.eyebrow{font:700 11px monospace;letter-spacing:.16em;color:#0077c8}.sheet h1{font-size:30px;margin:3mm 0 0}.status{border:1px solid #f59e0b;background:#fffbeb;color:#b45309;border-radius:4px;padding:6px 10px;font-weight:700}.order-grid{display:grid;grid-template-columns:1fr 1fr;gap:1px;background:#cbd5e1;border:1px solid #cbd5e1;margin-top:12mm}.order-grid div{background:#fff;padding:8mm}.order-grid span{display:block;color:#64748b;font-size:13px;margin-bottom:3mm}.order-grid strong{font:700 22px monospace}.barcode{margin-top:14mm;border:2px solid #0f172a;padding:8mm;text-align:center}.barcode>div{font-weight:700;margin-bottom:3mm}.barcode svg{width:100%;height:48mm}footer{display:flex;justify-content:space-between;margin-top:14mm;padding-top:8mm;border-top:1px solid #cbd5e1;color:#475569;font-size:13px}
            @media print{body{background:#fff}.toolbar{display:none}.sheet{margin:0;box-shadow:none;width:210mm;height:297mm;min-height:0;page-break-after:always}.sheet:last-child{page-break-after:auto}}@media(max-width:850px){.sheet{width:calc(100% - 24px);min-height:auto;padding:24px}.order-grid{grid-template-columns:1fr}.sheet h1{font-size:24px}footer{flex-direction:column;gap:6px}}
            </style></head><body><nav class=\"toolbar\"><strong>설비별 가상 PO 작업지 · 총 4장</strong><div><a href=\"/scanner\">라벨 스캐너</a><button onclick=\"window.print()\">전체 인쇄</button></div></nav>"""
            + "".join(sheets)
            + "</body></html>"
        ).replace(
            "총 4장", f"총 {len(sheets)}장"
        ))

    @app.post("/api/dashboard/refresh")
    async def refresh_dashboard() -> dict:
        return await service.refresh()

    @app.post("/api/labels", status_code=201)
    async def print_label(payload: PrintLabelRequest) -> dict:
        try:
            event = service.print_label(payload.po.strip(), payload.quantity)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="존재하지 않는 PO입니다.") from exc
        return {**event, "print_url": f"/labels/{event['id']}"}

    @app.get("/api/dashboard.csv")
    async def export_csv() -> Response:
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["설비명", "PO", "아이템명", "계획수량", "라벨 출력수량", "진행률"])
        for row in service.get_dashboard()["items"]:
            writer.writerow(
                [row["machine"], row["po"], row["item"], row["plan_qty"], row["printed_qty"], row["progress_rate"]]
            )
        return Response(
            content="\ufeff" + output.getvalue(),
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": 'attachment; filename="production-dashboard.csv"'},
        )

    @app.get("/labels/{event_id}", response_class=HTMLResponse)
    async def printable_label(event_id: int) -> HTMLResponse:
        event = repository.get_event(event_id)
        if event is None:
            raise HTTPException(status_code=404, detail="라벨 출력 기록을 찾을 수 없습니다.")
        barcode_svg = barcode.get("code128", event["barcode"], writer=SVGWriter()).render(
            writer_options={"write_text": True, "module_height": 12.0, "font_size": 8}
        ).decode("utf-8")
        safe_po = html.escape(str(event["po"]))
        safe_barcode = html.escape(str(event["barcode"]))
        label_html = f"""<!doctype html><html lang=\"ko\"><head><meta charset=\"utf-8\">
        <title>라벨 {safe_barcode}</title><style>
        @page{{size:100mm 60mm;margin:4mm}}body{{font-family:Arial,sans-serif;margin:0}}
        .label{{width:92mm;height:52mm;border:1px solid #111;padding:4mm;box-sizing:border-box}}
        h1{{font-size:18px;margin:0 0 4px}}.meta{{display:flex;justify-content:space-between;font-weight:700}}
        svg{{width:100%;height:30mm}}@media screen{{body{{padding:20px;background:#eee}}.label{{background:white}}}}
        </style></head><body><section class=\"label\"><h1>생산 라벨</h1>
        <div class=\"meta\"><span>PO {safe_po}</span><span>{event['quantity']:,} EA</span></div>
        {barcode_svg}</section><script>window.addEventListener('load',()=>window.print());</script></body></html>"""
        return HTMLResponse(label_html)

    return app


app = create_app()
