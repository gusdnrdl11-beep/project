from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path


if getattr(sys, "frozen", False):
    PROJECT_ROOT = Path(getattr(sys, "_MEIPASS")).resolve()
    RUNTIME_ROOT = Path(sys.executable).resolve().parent
else:
    PROJECT_ROOT = Path(__file__).resolve().parent.parent
    RUNTIME_ROOT = PROJECT_ROOT


@dataclass(frozen=True)
class Settings:
    database_path: Path = RUNTIME_ROOT / "data" / "labels.db"
    refresh_interval_seconds: float = 10_800
    data_provider: str = "dummy"
    company_api_base_url: str = ""
    company_api_token: str = ""
    company_api_timeout_seconds: float = 10.0

    @classmethod
    def from_env(cls) -> "Settings":
        raw_db_path = Path(os.getenv("DATABASE_PATH", "./data/labels.db"))
        database_path = raw_db_path if raw_db_path.is_absolute() else RUNTIME_ROOT / raw_db_path
        return cls(
            database_path=database_path,
            refresh_interval_seconds=float(os.getenv("REFRESH_INTERVAL_SECONDS", "10800")),
            data_provider=os.getenv("DATA_PROVIDER", "dummy").strip().lower(),
            company_api_base_url=os.getenv("COMPANY_API_BASE_URL", "").rstrip("/"),
            company_api_token=os.getenv("COMPANY_API_TOKEN", ""),
            company_api_timeout_seconds=float(os.getenv("COMPANY_API_TIMEOUT_SECONDS", "10")),
        )
