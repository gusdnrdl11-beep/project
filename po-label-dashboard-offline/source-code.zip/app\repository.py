from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path


class LabelEventRepository:
    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=10)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS label_print_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    po TEXT NOT NULL,
                    barcode TEXT NOT NULL,
                    quantity INTEGER NOT NULL CHECK (quantity > 0),
                    created_at TEXT NOT NULL
                )
                """
            )

    def create_event(self, po: str, barcode: str, quantity: int) -> dict:
        created_at = datetime.now(timezone.utc).isoformat()
        with self._connect() as connection:
            cursor = connection.execute(
                "INSERT INTO label_print_events(po, barcode, quantity, created_at) VALUES (?, ?, ?, ?)",
                (po, barcode, quantity, created_at),
            )
            event_id = int(cursor.lastrowid)
        return {"id": event_id, "po": po, "barcode": barcode, "quantity": quantity, "created_at": created_at}

    def totals_by_po(self) -> dict[str, int]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT po, COALESCE(SUM(quantity), 0) AS total FROM label_print_events GROUP BY po"
            ).fetchall()
        return {str(row["po"]): int(row["total"]) for row in rows}

    def get_event(self, event_id: int) -> dict | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT id, po, barcode, quantity, created_at FROM label_print_events WHERE id = ?",
                (event_id,),
            ).fetchone()
        return dict(row) if row else None

