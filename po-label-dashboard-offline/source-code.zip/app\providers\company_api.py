from __future__ import annotations

import httpx

from app.domain import ProductionOrder


class CompanyApiProvider:
    """사내 API 어댑터 예시.

    실제 승인 후에는 `_map_order`와 엔드포인트만 회사 API 명세에 맞추면
    서비스, DB, 화면 코드는 그대로 사용할 수 있다.
    """

    def __init__(self, base_url: str, token: str, timeout_seconds: float = 10.0) -> None:
        if not base_url:
            raise ValueError("COMPANY_API_BASE_URL이 필요합니다.")
        self.base_url = base_url
        self.token = token
        self.timeout_seconds = timeout_seconds

    async def list_orders(self) -> list[ProductionOrder]:
        headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            response = await client.get(f"{self.base_url}/production-orders", headers=headers)
            response.raise_for_status()
            payload = response.json()
        rows = payload.get("items", payload) if isinstance(payload, dict) else payload
        return [self._map_order(row) for row in rows]

    @staticmethod
    def _map_order(row: dict) -> ProductionOrder:
        return ProductionOrder(
            po=str(row["po"]),
            machine=str(row["machine"]),
            item=str(row["item"]),
            plan_qty=int(row["plan_qty"]),
            base_printed_qty=int(row.get("printed_qty", 0)),
        )

