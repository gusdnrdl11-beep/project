from __future__ import annotations

from typing import Protocol

from app.domain import ProductionOrder


class ProductionDataProvider(Protocol):
    """PO 원천 데이터 계약. 사내 API 연동 시 이 계약만 구현하면 된다."""

    async def list_orders(self) -> list[ProductionOrder]: ...

