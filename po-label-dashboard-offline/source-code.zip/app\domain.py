from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class ProductionOrder:
    po: str
    machine: str
    item: str
    plan_qty: int
    base_printed_qty: int

    def as_dict(self) -> dict[str, str | int]:
        return asdict(self)

