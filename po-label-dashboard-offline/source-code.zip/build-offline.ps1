$ErrorActionPreference = 'Stop'
$projectPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$outputPath = Join-Path (Split-Path -Parent $projectPath) 'po-label-dashboard-offline'
$workPath = Join-Path (Split-Path -Parent (Split-Path -Parent $projectPath)) 'work\pyinstaller-build'
$specPath = Join-Path (Split-Path -Parent (Split-Path -Parent $projectPath)) 'work'

Set-Location -LiteralPath $projectPath
& .\.venv\Scripts\python.exe -m pip install pyinstaller==6.16.0
& .\.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir `
    --name PO-Label-Dashboard `
    --distpath $outputPath `
    --workpath $workPath `
    --specpath $specPath `
    --add-data "$projectPath\static;static" `
    --collect-all barcode `
    --collect-all uvicorn `
    offline_launcher.py

