from __future__ import annotations

import os
import socket
import threading
import time
import urllib.request
import webbrowser

import uvicorn

from app.main import app


def choose_port() -> int:
    requested = os.getenv("DASHBOARD_PORT")
    candidates = [int(requested)] if requested else list(range(8010, 8021))
    for port in candidates:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as candidate:
            try:
                candidate.bind(("127.0.0.1", port))
            except OSError:
                continue
        return port
    raise RuntimeError("8010~8020 범위에서 사용 가능한 포트를 찾지 못했습니다.")


def open_when_ready(url: str) -> None:
    for _ in range(50):
        try:
            with urllib.request.urlopen(url, timeout=1) as response:
                if response.status == 200:
                    webbrowser.open(url)
                    return
        except Exception:
            time.sleep(0.1)


def main() -> None:
    port = choose_port()
    url = f"http://127.0.0.1:{port}/"
    print("=" * 60)
    print("  PO 라벨 집계 대시보드 - 오프라인 실행")
    print(f"  주소: {url}")
    print("  종료: 이 창에서 Ctrl+C")
    print("=" * 60)
    if os.getenv("DASHBOARD_NO_BROWSER") != "1":
        threading.Thread(target=open_when_ready, args=(url,), daemon=True).start()
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="info")


if __name__ == "__main__":
    main()
