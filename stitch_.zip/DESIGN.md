---
name: Precision Industrial Telemetry
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#404751'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#717783'
  outline-variant: '#c0c7d3'
  surface-tint: '#0061a5'
  primary: '#005e9f'
  on-primary: '#ffffff'
  primary-container: '#0077c8'
  on-primary-container: '#fbfbff'
  inverse-primary: '#9fcaff'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#8c4a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#b05f00'
  on-tertiary-container: '#fffbfa'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d2e4ff'
  primary-fixed-dim: '#9fcaff'
  on-primary-fixed: '#001d36'
  on-primary-fixed-variant: '#00497e'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  metric-xl:
    fontFamily: JetBrains Mono
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  metric-lg:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system is engineered for industrial operational intelligence, mission-critical manufacturing execution systems (MES), and high-throughput telemetry monitoring. The aesthetic blends high-precision engineering with modern data ergonomics. It conveys absolute reliability, structural discipline, and immediate cognitive clarity under high-stress factory floor and control room environments.

The visual style is **Corporate / Modern** inflected with **Technical Precision**:
- High signal-to-noise ratio: Decorative distractions are eliminated in favor of pristine surfaces, structured data hierarchies, and intentional status-driven color triggers.
- Uncompromising legibility: High-contrast typography ensures real-time metrics, line efficiencies (OEE), and machine states can be audited at a glance across multiple physical distances.
- Industrial rigor: Controlled spacing, sharp information grids, and surgical micro-interactions communicate instrumentation-grade dependability.

## Colors

The palette is tuned specifically for sustained analytical focus, high ambient light environments, and rapid anomaly detection.

- **Primary (`#0077C8`)**: An electric precision cyan/blue used for core interactive elements, active telemetry toggles, primary machine runs, and structural navigational states.
- **Secondary (`#059669`)**: A vivid, clinical emerald green reserved for nominal states, optimal throughput indications, calibration passes, and active production line statuses.
- **Tertiary (`#D97706`)**: A focused industrial amber utilized for cautionary drift, warning tolerances, and preventive maintenance triggers.
- **Critical / Danger (`#DC2626`)**: An assertive crimson used strictly for emergency stops, telemetry threshold violations, line jams, and critical faults.
- **Neutrals (`#64748B`)**: Layered across pristine base coats (`#FFFFFF` app canvas, `#F8FAFC` secondary paneling) and structured by subtle slate borders (`#E2E8F0`). High-contrast dark slate (`#0F172A`) is assigned to operational metrics and primary typography to guarantee effortless legibility.

## Typography

The typographic system utilizes a tri-font structure purpose-built for telemetry data parsing:

1. **Space Grotesk (Headlines & Section Titles)**: Delivers a clean, geometric architectural identity reminiscent of industrial precision machinery and modern engineering blueprints.
2. **Inter (Body & Interface Copy)**: Provides neutral, clear, and highly legible text rendering for operational notes, alerts, and systemic instructions.
3. **JetBrains Mono (Metrics, Data Tables, & Status Labels)**: Ensures tabular alignment across telemetry streams, timestamps, sensor readings, and parts-per-hour metrics without horizontal jitter during dynamic real-time updates.

All critical numbers and KPI displays must leverage tabular figures (`font-variant-numeric: tabular-nums`) to prevent layout shifts during live data re-renders.

## Layout & Spacing

The layout model is governed by a high-density, 12-column fluid grid system engineered for widescreen telemetry consoles and rugged shop-floor tablets.

- **Grid Geometry**: Employs a 12-column structure with `1.5rem` gutters on desktop displays (≥1280px), collapsing to an 8-column layout with `1rem` gutters on tablet monitors (768px–1279px), and a responsive 4-column flow with `0.75rem` gutters on ruggedized mobile units (<768px).
- **Rhythm & Padding**: Interfaces strictly adhere to an 8px spatial module. Micro-measurements (padding inside compact badges, table cells, metric tiles) utilize `0.25rem` (`4px`) and `0.5rem` (`8px`) increments to maintain optimal data density without visual overcrowding.
- **Reflow Discipline**: Production telemetry cards, live charts, and sensor strips reflow predictably; sensor gauges maintain fixed aspect ratios while table grids prioritize horizontal scroll containment with pinned primary asset IDs.

## Elevation & Depth

This design system favors **tonal layering combined with low-contrast structural outlines and ambient soft micro-shadows**.

- **Surfaces**: Canvas backgrounds rest on `#F8FAFC`. Base containers and telemetry cards use pure `#FFFFFF`. Elevated panels (such as flyout diagnostic drawers or active machine inspections) shift to `#FFFFFF` supported by crisp 1px borders in `#E2E8F0`.
- **Shadow Profile**: Shadows avoid dark, murky smudges. They are engineered as extra-diffused ambient light projections:
  - *Resting Card*: `0px 1px 3px rgba(15, 23, 42, 0.04), 0px 1px 2px rgba(15, 23, 42, 0.02)`
  - *Interactive Hover / Focused Stream*: `0px 4px 12px -2px rgba(0, 119, 200, 0.08), 0px 2px 6px -1px rgba(15, 23, 42, 0.04)`
  - *Floating Modal / Critical Diagnostic Panel*: `0px 12px 32px -4px rgba(15, 23, 42, 0.08), 0px 4px 12px -2px rgba(15, 23, 42, 0.03)`
- **Structural Outlines**: All interactive containers and modular data tiles use a consistent 1px border (`#E2E8F0`), creating a technical, modular chassis across the entire dashboard interface.

## Shapes

The design system employs a **Soft (`1`)** shape language:
- Core interactive components (buttons, input fields, dropdown triggers, and status badges) adhere to a crisp `0.25rem` (`4px`) corner radius.
- Data containers, metric cards, and telemetry visualization canvases utilize `rounded-lg` (`0.5rem` / `8px`).
- Modal dialogs and diagnostic slide-outs leverage `rounded-xl` (`0.75rem` / `12px`).

This subtle roundness removes harsh pixel cuts while retaining an architectural, calibrated, and technical demeanor suited to industrial software. Full pill shapes are strictly forbidden except for live machine pulse beacons.

## Components

### Buttons
- **Primary**: Solid `#0077C8` background with pure white text, 1px border (`#0066AA`), `rounded` (`4px`), `font-weight: 500`. Hover state deepens to `#0066AA` with an ambient cyan glow.
- **Secondary**: `#FFFFFF` background, 1px border in `#CBD5E1`, text in `#0F172A`. Hover transitions background to `#F8FAFC` and border to `#94A3B8`.
- **Destructive / Emergency Action**: `#DC2626` background with white text; active state provides instant optical snap without delayed transitions.
- **Sizing**: Compact operational sizing (32px default height, 40px touch-target height for plant-floor touch screens).

### Metric Cards (KPI Tiles)
- Crisp `#FFFFFF` surface with a 1px `#E2E8F0` border and resting elevation shadow.
- Header displays machine identifier or metric label using `label-sm` in `#64748B`.
- Primary value renders in `metric-xl` or `metric-lg` using JetBrains Mono in `#0F172A`.
- Footer incorporates inline delta badges with trending arrows: emerald `#059669` for positive efficiency drift, red `#DC2626` for negative throughput variance.

### Telemetry Tables
- Header row anchored with `#F8FAFC` background, 1px bottom border `#CBD5E1`, text in uppercase `label-sm` (`#475569`).
- Data rows feature alternating subtle zebra striping (`#FFFFFF` to `#FBFCFD`) with hover highlight in `#F1F5F9`.
- Numeric data columns align right with tabular mono figures. Leftmost asset IDs are sticky during horizontal scroll.
- Dense vertical padding (`8px` top/bottom) maximizes displayed line items per screen.

### Status Chips & Badges
- Pill-free, soft-squared tags (`4px` radius) with `0.25rem` horizontal padding.
- Nominal / Operating: `#ECFDF5` background, `#059669` text, `1px solid #A7F3D0`.
- Standby / Idling: `#F8FAFC` background, `#475569` text, `1px solid #E2E8F0`.
- Warning / Drift: `#FFFBEB` background, `#D97706` text, `1px solid #FDE68A`.
- Alarm / Fault: `#FEF2F2` background, `#DC2626` text, `1px solid #FECACA`.

### Form Inputs & Controls
- Checkboxes and radios utilize sharp `4px` and circular footprints respectively, bordered by `#94A3B8`. Active check state triggers `#0077C8` fill with crisp white vector markings.
- Text inputs and parameter inputs feature `#FFFFFF` fill, 1px `#CBD5E1` border, transitioning to a sharp 1px `#0077C8` ring on `:focus-visible`.

### Live Status Indicators & Beacons
- Embedded 8px pulsating status nodes signaling continuous telemetry streaming.
- Nominal streams pulse with a synchronized soft emerald wave (`rgba(5, 150, 105, 0.25)`); severed feeds immediately freeze to solid `#94A3B8`.